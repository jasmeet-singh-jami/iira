// src/components/IncidentResolution.js
import React from 'react';
import { Search, Loader2, Play, AlertCircle } from 'lucide-react';

const IncidentResolution = ({
    incidentNumber,
    setIncidentNumber,
    resolveIncident,
    loading,
    incidentDetails,
    resolvedScripts
}) => {
    // Handle Enter key press
    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            resolveIncident();
        }
    };

    return (
        <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-blue-800 mb-6 border-b-2 pb-2 border-blue-100">
                Resolve Incident
            </h2>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 mb-6">
                <input
                    type="text"
                    value={incidentNumber}
                    onChange={e => setIncidentNumber(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Enter an incident number (e.g., INC001)"
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
                />
                <button
                    onClick={resolveIncident}
                    className="flex items-center justify-center px-8 py-3 bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 transition duration-300"
                    disabled={loading}
                >
                    {loading ? (<Loader2 className="animate-spin h-5 w-5 mr-2" />) : (<Search size={20} className="mr-2" />)}
                    Resolve
                </button>
            </div>

            {loading && <div className="text-center py-8 text-gray-500 text-lg">Searching for a resolution...</div>}

            {incidentDetails && (
                <div className="mt-8 bg-blue-50 p-6 rounded-2xl shadow-inner border border-blue-200">
                    <h3 className="text-2xl font-bold text-blue-800 mb-2">Incident: {incidentDetails.number}</h3>
                    <p className="text-lg font-semibold text-gray-700 mb-2">{incidentDetails.short_description}</p>
                    <p className="text-gray-600">{incidentDetails.description}</p>
                    <div className="flex flex-wrap mt-4 space-x-4 text-sm font-medium">
                        <span className="bg-blue-200 text-blue-800 px-3 py-1 rounded-full">Status: {incidentDetails.state}</span>
                        <span className="bg-blue-200 text-blue-800 px-3 py-1 rounded-full">Host: {incidentDetails.host}</span>
                        <span className="bg-blue-200 text-blue-800 px-3 py-1 rounded-full">Assigned To: {incidentDetails.assigned_to}</span>
                    </div>
                </div>
            )}

            {resolvedScripts.length > 0 && (
                <div className="mt-8">
                    <h3 className="text-2xl font-bold text-blue-800 mb-4">Proposed Resolution Workflow</h3>
                    <div className="space-y-6">
                        {resolvedScripts.map((script, index) => (
                            <div key={index} className="bg-gray-50 p-6 rounded-2xl shadow-inner border border-gray-200 flex items-start space-x-4 animate-fade-in" >
                                <div className="flex items-center justify-center w-10 h-10 bg-blue-600 text-white font-bold rounded-full text-xl flex-shrink-0">{index + 1}</div>
                                <div className="flex-1">
                                    <p className="text-lg font-semibold text-gray-800 mb-2">{script.step_description}</p>
                                    {script.script_name && (
                                        <div className="bg-gray-200 text-gray-700 p-3 rounded-lg font-mono text-sm">
                                            <span className="font-bold text-blue-700">Script:</span> {script.script_name}
                                            {script.extracted_parameters && Object.keys(script.extracted_parameters).length > 0 && (
                                                <div className="mt-2 text-xs">
                                                    <span className="font-bold text-blue-700">Parameters:</span>
                                                    <ul className="list-disc list-inside ml-4">
                                                        {Object.entries(script.extracted_parameters).map(([paramName, paramValue], i) => {
                                                            // Find the corresponding parameter in the `parameters` array to get the default value
                                                            const paramDefinition = script.parameters.find(p => p.param_name === paramName);
                                                            const defaultValue = paramDefinition ? paramDefinition.default_value : null;

                                                            return (
                                                                <li key={i} className="flex items-center space-x-2 my-1">
                                                                    <span className="font-bold text-gray-800">{paramName}:</span>
                                                                    {paramValue ? (
                                                                        <span className="bg-green-600/30 text-green-700 px-2 py-0.5 rounded-md font-semibold">"{paramValue}"</span>
                                                                    ) : (
                                                                        <div className="flex items-center space-x-2">
                                                                            <span className="bg-red-600/30 text-red-700 px-2 py-0.5 rounded-md font-semibold">Value Not Found</span>
                                                                            {defaultValue && (
                                                                                <span className="bg-gray-400/30 text-gray-700 px-2 py-0.5 rounded-md font-semibold">Default: "{defaultValue}"</span>
                                                                            )}
                                                                        </div>
                                                                    )}
                                                                </li>
                                                            );
                                                        })}
                                                    </ul>
                                                </div>
                                            )}
                                        </div>
                                    )}
                                    {!script.script_name && (
                                        <div className="bg-yellow-100 text-yellow-800 p-3 rounded-lg font-semibold text-sm">
                                            <AlertCircle size={16} className="inline mr-2" />
                                            No matching script found for this step.
                                        </div>
                                    )}
                                </div>
                                <button
                                    className="flex-shrink-0 p-2 bg-green-500 text-white rounded-full shadow-md hover:bg-green-600 transition duration-300"
                                    title="Execute Script"
                                >
                                    <Play size={20} />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default IncidentResolution;
